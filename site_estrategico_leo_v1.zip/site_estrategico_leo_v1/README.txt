# Studio Moreno — Site estático (versão estratégica)

Este pacote reflete a imagem estratégica que você quer transmitir: **profissional sólido e criativo**, com **confiança serena**, **autoridade acessível** e equilíbrio entre **técnica e sensibilidade**.

## Como abrir
1. Baixe o `.zip` abaixo.
2. Extraia a pasta.
3. Abra `index.html` no navegador.

## Onde trocar conteúdos
- **Texto**: edite `index.html` (HERO, Manifesto, Abordagem, Projetos, Laboratório e Contato).
- **Cores**: em `assets/css/style.css` altere as variáveis `--accent`, `--bg`, `--text` (no topo).
- **Imagens**: substitua os arquivos em `assets/img/` (hero.jpg, proj1.jpg, proj2.jpg, proj3.jpg) por suas fotos.
  - Mantenha os mesmos nomes para não precisar mudar o HTML.
- **Tipografia**: por padrão usa fontes do sistema (sem internet). Se quiser Google Fonts, insira o `<link>` no `<head>`.

## Estrutura
site_estrategico_leo_v1/
├─ index.html
└─ assets/
   ├─ css/style.css
   ├─ js/main.js
   └─ img/
      ├─ hero.jpg
      ├─ proj1.jpg
      ├─ proj2.jpg
      └─ proj3.jpg

## Notas de linguagem visual
- Base neutra com **terracota sóbrio** como acento (acessível e caloroso).
- Layout limpo, com **rótulos em monoespaçada** (clareza de processo).
- Cartões e seções com **bordas discretas** e **leve textura** (proximidade sem perder rigor).
- Sessões que comunicam **processo**, não só resultado (autoridade acessível).
